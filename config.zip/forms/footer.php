	<!--<footer id="footer-area section_gap">
		
	</footer>-->


<footer class="footer-area section_gap">
		<div class="container">
			<div class="row">
				
				<div class="col-lg-4  col-md-6">
					<div class="single-footer-widget mail-chimp">
						<h3 class="mb-20">Contactos</h3>
						<p>
							Km. 11 1/2  Vía a Daule (Peca), Guayaquil-Ecuador
						</p>
						<h6>2586213</h6>
						<h6>info@laboratoriololy.com</h6>
						<!-- <h3>012-6532-568-9746</h3>
						<h3>012-6532-568-97468</h3> -->
					</div>
				</div>
				<div class="col-lg-6  col-md-12">
					<!-- <div class="single-footer-widget newsletter">
						<h6>Sucursales</h6>
						<p><strong>Dirección: </strong> GYE &#8211;.<br />
<strong>Tel:</strong> 042594010</p>
						<p> </p>
						<div id="mc_embed_signup">

						</div>
					</div> -->
				</div>
			</div>

			<div class="row footer-bottom d-flex justify-content-between">
				<p class="col-lg-8 col-sm-12 footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script>  <i class="fa fa-heart-o" aria-hidden="true"></i> <a href="https://www.facebook.com/Laboratorio-LOLY-1758736761077192/" target="_blank">Laboratorio Loly - Ecuador</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
				</p>
				<div class="col-lg-4 col-sm-12 footer-social">
					<a href="https://es-la.facebook.com/pages/category/Medical-Service/Laboratorio-LOLY-1758736761077192/" title="Facebook">
						<i class="fa fa-facebook"></i>
					</a>
					<a href="#" title="Twitter">
						<i class="fa fa-twitter"></i>
					</a>
					<!-- <a href="#">
						<i class="fab fa-dribbble"></i>
					</a>
					<a href="#">
						<i class="fab fa-behance"></i>
					</a> -->
				</div>
			</div>
		</div>
	</footer>