<?php
 $host = "localhost";
 $user = "root";
 $password = "root";
 $db = "loly";

 $conexion = mysqli_connect($host,$user,$password) or die ("Error al conectar con Base de datos");

  ?>
