<?php
	$con=mysqli_connect("localhost", "laborio2_root123", "Loly_root*", "laborio2_loly") or die ("error".mysqli_error());
	date_default_timezone_set('America/Guayaquil');
?>